function fCancel() {
    alert("Hello Web Engineering")
}

function fSubmit() {
    alert("Thanks for adding your task!")
}