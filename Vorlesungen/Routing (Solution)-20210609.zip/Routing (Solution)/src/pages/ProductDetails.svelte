<script>
    export let params = {};
</script>

<h1>Product Details</h1>

<!-- TODO: Display the path paramater "id" -->
<p>ID: {params.id}</p>

<!-- TODO: Add a link "Back to the list of products" to go back to the page "products" -->
<a href="#/products">Back to the list of products</a>